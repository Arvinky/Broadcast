//
//  ViewController.m
//  Broadcast
//
//  Created by 石晴露 on 2017/8/11.
//  Copyright © 2017年 Arvin.shi. All rights reserved.
//

#import "ViewController.h"
#import "BroadcastHandle.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[BroadcastHandle shareInstance] setUpdataState:^(CBManagerState state){
        if (state!=CBManagerStatePoweredOn) {
            NSURL *url = [NSURL URLWithString:@"prefs:root=General&path=Bluetooth"];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }else{
            [self sendData];
        }
    }];
}
- (void)sendData {
    Byte byte[22] = {0,1,2,3,4,5,6,7,8,9,0xa,0xb,0xc,0xd,0xe,0xf,0x10,0x11,0x12,0x13,0x14,0x15};
    Broadcast(byte, 22);
}
- (IBAction)startAdvertisment:(UISwitch *)sender {
    if (sender.on) {
        if ([BroadcastHandle shareInstance].manager.state==CBManagerStatePoweredOn) {
            [self sendData];
        }else{
            return;
        }
    }else{
        [[BroadcastHandle shareInstance].manager stopAdvertising];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
